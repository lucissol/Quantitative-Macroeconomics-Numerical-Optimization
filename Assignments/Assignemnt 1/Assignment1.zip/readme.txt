Quantitative Macroeconomics and Numerical Methods | First Assignment
Louis Brune
ID: 8514718
Luca Seibert
ID: 8511270
João Cordeiro
ID: 8509509

We are handing in the full first two questions.
The zip file contains a written report and a Python file. The file 'assignmentfile1.py' contains the full Python script with which the results were obtained. Although the code is optimised for the Spyder IDE, it will run in any environment.